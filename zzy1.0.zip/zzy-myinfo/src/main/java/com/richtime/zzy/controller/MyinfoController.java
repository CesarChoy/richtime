package com.richtime.zzy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.richtime.common.pojo.Invest;
import com.richtime.common.pojo.Item;
import com.richtime.common.pojo.Loan;
import com.richtime.common.vo.MyResult;
import com.richtime.zzy.mapper.MyinfoMapper;

@Controller
public class MyinfoController {
	
	@Autowired
	private MyinfoMapper userMapper;
	@RequestMapping("user/myself/{userId}")
	@ResponseBody
	// 获取用户的投资贷款信息
	public MyResult queryList(@PathVariable String userId){
		
		List<Invest> invests = userMapper.queryLists(userId);
		List<Loan> loans = userMapper.queryLoans(userId);
		// MyResult对结果进行封装
		MyResult result = new MyResult();
		result.setInvests(invests);
		result.setLoans(loans);
		return result;
	}
	
	/*@RequestMapping("user/myself/{currentPage},{rows}")
	public Page queryPage(){
		
	}*/
	
	
	
}
