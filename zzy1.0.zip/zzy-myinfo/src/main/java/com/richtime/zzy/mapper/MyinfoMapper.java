package com.richtime.zzy.mapper;

import java.util.List;

import com.richtime.common.pojo.Invest;
import com.richtime.common.pojo.Loan;



public interface MyinfoMapper {

	List<Invest> queryLists(String userId);

	List<Loan> queryLoans(String userId);


}
