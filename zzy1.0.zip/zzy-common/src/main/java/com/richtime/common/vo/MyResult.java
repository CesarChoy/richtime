package com.richtime.common.vo;

import java.util.List;

import com.richtime.common.pojo.Invest;
import com.richtime.common.pojo.Item;
import com.richtime.common.pojo.Loan;
import com.richtime.common.pojo.User;

public class MyResult {
	//投资表
	private List<Invest> invests;
	//贷款表
	private List<Loan> loans;
	//项目表
	private List<Item> items;
	
	private User user; 
	
	//1表示成功，0表示失败
	private Integer status;

	public List<Invest> getInvests() {
		return invests;
	}

	public void setInvests(List<Invest> invests) {
		this.invests = invests;
	}

	public List<Loan> getLoans() {
		return loans;
	}

	public void setLoans(List<Loan> loans) {
		this.loans = loans;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	

	

	
}
