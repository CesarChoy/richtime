package com.richtime.common.pojo;

import java.util.Date;

//贷款信息
public class Loan {
	
	private String loansId;
	private float loansMoney;
	private Date loansDate;
	private float loansRate;
	public String getLoansId() {
		return loansId;
	}
	public void setLoansId(String loansId) {
		this.loansId = loansId;
	}
	public float getLoansMoney() {
		return loansMoney;
	}
	public void setLoansMoney(float loansMoney) {
		this.loansMoney = loansMoney;
	}
	public Date getLoansDate() {
		return loansDate;
	}
	public void setLoansDate(Date loansDate) {
		this.loansDate = loansDate;
	}
	public float getLoansRate() {
		return loansRate;
	}
	public void setLoansRate(float loansRate) {
		this.loansRate = loansRate;
	}
	public int getLoansPeriods() {
		return loansPeriods;
	}
	public void setLoansPeriods(int loansPeriods) {
		this.loansPeriods = loansPeriods;
	}
	public float getLoansReturnMoney() {
		return loansReturnMoney;
	}
	public void setLoansReturnMoney(float loansReturnMoney) {
		this.loansReturnMoney = loansReturnMoney;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLoansStatus() {
		return loansStatus;
	}
	public void setLoansStatus(String loansStatus) {
		this.loansStatus = loansStatus;
	}
	private int loansPeriods;
	private float loansReturnMoney;
	private String userId;
	private String loansStatus;
}
