package com.richtime.common.pojo;

import java.math.BigDecimal;

public class User {
	private String userId;
	private String userPhone;
	private String userPassword;
	private String userNickname;
	private float userCash;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserNickname() {
		return userNickname;
	}
	public void setUserNickname(String userNickname) {
		this.userNickname = userNickname;
	}
	public float getUserCash() {
		return userCash;
	}
	public void setUserCash(float userCash) {
		this.userCash = userCash;
	}
	
	
	
	
	
}
