package com.richtime.common.vo;

public class HomePageTotalInfo {
	private float totalInvestMoney;
	private float totalLoanMoney;
	private int itemNumber;
	private int userNumber;
	public float getTotalInvestMoney() {
		return totalInvestMoney;
	}
	public void setTotalInvestMoney(float totalInvestMoney) {
		this.totalInvestMoney = totalInvestMoney;
	}
	public float getTotalLoanMoney() {
		return totalLoanMoney;
	}
	public void setTotalLoanMoney(float totalLoanMoney) {
		this.totalLoanMoney = totalLoanMoney;
	}
	public int getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(int itemNumber) {
		this.itemNumber = itemNumber;
	}
	public int getUserNumber() {
		return userNumber;
	}
	public void setUserNumber(int userNumber) {
		this.userNumber = userNumber;
	}
	
}
