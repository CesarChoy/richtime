package com.richtime.common.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

//伪service，其实是个component
@Service
public class RedisService {
	@Autowired(required=false)
	private ShardedJedisPool pool;
		
	public String get(String key){
		ShardedJedis jedis = pool.getResource();
		String value = jedis.get(key);
		pool.returnResource(jedis);
		return value; 
	}
	
	public Boolean exists(String key){
		ShardedJedis jedis = pool.getResource();
		Boolean value = jedis.exists(key);
		pool.returnResource(jedis);
		return value;
	}
	public void set(String key,String jsonData){
		ShardedJedis jedis = pool.getResource();
		jedis.set(key,jsonData);
		pool.returnResource(jedis);
	}
	
}
