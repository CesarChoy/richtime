package com.richtime.common.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedisPool;

/*
 * 利用配置类，完成pool对象的初始化过程
 * 并交给spring框架维护
 */

@Configuration
public class JedisShardConfig {
	@Value("${spring.redis.nodes:1}")
	private String nodes;
	@Value("${spring.redis.config.maxTotal:1}")
	private Integer maxTotal;
	@Value("${spring.redis.config.maxIdle:1}")
	private Integer maxIdle;
	@Value("${spring.redis.config.minIdle:1}")
	private Integer minIdle;
	
	//创建连接池对象，并初始化
	//此处注解表示方法返回值已经在spring框架维护
	@Bean
	public ShardedJedisPool init(){
		try {
			//收集节点信息
			List<JedisShardInfo> infoList = new ArrayList<JedisShardInfo>();
			String[] infos = nodes.split(",");
			for(String node:infos){
				JedisShardInfo info1 = new JedisShardInfo(infos[0].split(":")[0],Integer.parseInt(infos[0].split(":")[1]));
				infoList.add(info1);
				}
			
			//配置连接池属性
			GenericObjectPoolConfig config = new GenericObjectPoolConfig();
			config.setMaxTotal(maxTotal);
			config.setMaxIdle(maxIdle);
			config.setMinIdle(minIdle);
			ShardedJedisPool pool = new ShardedJedisPool(config, infoList);
			return pool;
		} catch (Exception e) {
			return null;
		}
		
		
	}
	
}
