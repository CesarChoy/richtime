package com.richtime.common.pojo;

import java.util.Date;

public class Invest {
	private String investId;
	private String userId;
	private String itemId;
	private float investTotalMoney;
	private String itemName;
	private float itemRate;
	private Date investDate;
	public String getInvestId() {
		return investId;
	}
	public void setInvestId(String investId) {
		this.investId = investId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public float getInvestTotalMoney() {
		return investTotalMoney;
	}
	public void setInvestTotalMoney(float investTotalMoney) {
		this.investTotalMoney = investTotalMoney;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getItemRate() {
		return itemRate;
	}
	public void setItemRate(float itemRate) {
		this.itemRate = itemRate;
	}
	public Date getInvestDate() {
		return investDate;
	}
	public void setInvestDate(Date investDate) {
		this.investDate = investDate;
	}
	
}
