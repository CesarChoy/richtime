package com.richtime.common.pojo;

import java.util.Date;

//项目信息
public class Item {
	private String itemId;
	private String itemName;
	private String itemTime;
	private float itemRate;
	private float itemTotal;
	private float itemCurrent;
	private String itemStatus;
	private String itemCompany;
	private String itemLocation;
	private String itemDescription;
	private Date itemStartTime;
	private float itemQuota;
	private Date itemSeckillStart;
	private Date itemSeckillStop;
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemTime() {
		return itemTime;
	}
	public void setItemTime(String itemTime) {
		this.itemTime = itemTime;
	}
	public float getItemRate() {
		return itemRate;
	}
	public void setItemRate(float itemRate) {
		this.itemRate = itemRate;
	}
	public float getItemTotal() {
		return itemTotal;
	}
	public void setItemTotal(float itemTotal) {
		this.itemTotal = itemTotal;
	}
	public float getItemCurrent() {
		return itemCurrent;
	}
	public void setItemCurrent(float itemCurrent) {
		this.itemCurrent = itemCurrent;
	}
	public String getItemStatus() {
		return itemStatus;
	}
	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}
	public String getItemCompany() {
		return itemCompany;
	}
	public void setItemCompany(String itemCompany) {
		this.itemCompany = itemCompany;
	}
	public String getItemLocation() {
		return itemLocation;
	}
	public void setItemLocation(String itemLocation) {
		this.itemLocation = itemLocation;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public Date getItemStartTime() {
		return itemStartTime;
	}
	public void setItemStartTime(Date itemStartTime) {
		this.itemStartTime = itemStartTime;
	}
	public float getItemQuota() {
		return itemQuota;
	}
	public void setItemQuota(float itemQuota) {
		this.itemQuota = itemQuota;
	}
	public Date getItemSeckillStart() {
		return itemSeckillStart;
	}
	public void setItemSeckillStart(Date itemSeckillStart) {
		this.itemSeckillStart = itemSeckillStart;
	}
	public Date getItemSeckillStop() {
		return itemSeckillStop;
	}
	public void setItemSeckillStop(Date itemSeckillStop) {
		this.itemSeckillStop = itemSeckillStop;
	}
	
	
	
}
