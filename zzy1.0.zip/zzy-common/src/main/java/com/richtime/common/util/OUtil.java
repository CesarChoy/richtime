package com.richtime.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class OUtil {
	public static final ObjectMapper mapper=new ObjectMapper();
}
