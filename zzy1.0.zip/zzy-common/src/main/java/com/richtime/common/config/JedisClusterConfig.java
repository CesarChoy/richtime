package com.richtime.common.config;
/*package my.ltq.easymall.config;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

@Configuration
public class JedisClusterConfig {
	
	@Value("${spring.redis.config.maxTotal}")
	private Integer maxTotal;
	@Value("${spring.redis.config.maxIdle}")
	private Integer maxIdle;
	@Value("${spring.redis.config.minIdle}")
	private Integer minIdle;
	@Value("${spring.redis.cluster.nodes}")
	private String nodes;
	
	@Bean
	public JedisCluster init(){
		Set<HostAndPort> set = new HashSet<HostAndPort>();
		String[] hostAndPort = nodes.split(",");
		for(String node:hostAndPort){
			String ip = node.split(":")[0];
			int port = Integer.parseInt(node.split(":")[1]);
			set.add(new HostAndPort(ip, port));
		}
		GenericObjectPoolConfig config = new GenericObjectPoolConfig();
		config.setMaxTotal(maxTotal);
		config.setMaxIdle(maxIdle);
		config.setMinIdle(minIdle);
		JedisCluster cluster = new JedisCluster(set, config);
		return cluster;
	}
}
*/