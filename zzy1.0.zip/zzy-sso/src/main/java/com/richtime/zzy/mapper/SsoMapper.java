package com.richtime.zzy.mapper;

import com.richtime.common.pojo.User;

public interface SsoMapper {

	/**
	 * 判断手机是否已被注册
	 * @param userPhone 手机号码
	 * @return 状态 1 存在 0 不存在
	 */
	Integer checkUserPhone(String userPhone);

	/**
	 * 注册用户
	 * @param user 用户
	 * @return 状态 1 注册成功 0 注册失败
	 */
	Integer saveUser(User user);

	/**
	 * 查询手机号与密码是否匹配
	 * @param user 用户携带手机号、密码
	 * @return User 所有用户信息
	 */
	User login(User user);

}
