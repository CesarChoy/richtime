package com.richtime.zzy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.richtime.common.config.RedisService;
import com.richtime.common.pojo.User;
import com.richtime.common.util.MD5Util;
import com.richtime.common.util.OUtil;
import com.richtime.common.util.UUIDUtil;
import com.richtime.common.vo.SysResult;
import com.richtime.zzy.mapper.SsoMapper;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

@Controller
public class SsoController {
	@Autowired
	private SsoMapper userMapper;

	// 校验手机号码
	@RequestMapping("/user/check/{userPhone}")
	@ResponseBody
	public SysResult checkUsername(@PathVariable String userPhone) {
		try {
			Integer exist = userMapper.checkUserPhone(userPhone);
			if (exist == 1) {
				return SysResult.build(200, "查询完毕");
			} else {
				return SysResult.build(201, "查询不到");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return SysResult.build(201, e.getMessage());
		}
	}

	// 注册用户
	@RequestMapping("/user/register")
	@ResponseBody
	public SysResult saveUser(User user) {
		try {
			// 判断手机是否已被注册
			Integer exist = userMapper.checkUserPhone(user.getUserPhone());
			if (exist == 1) {
				return SysResult.build(201, "新增用户失败");
			}
			// 新增用户
			user.setUserId(UUIDUtil.getUUID());
			user.setUserPassword(MD5Util.md5(user.getUserPassword()));
			int success = userMapper.saveUser(user);
			if (success == 1) {// 新增成功
				return SysResult.build(200, "");
			}
			return SysResult.build(201, "新增用户失败");
		} catch (Exception e) {
			e.printStackTrace();
			return SysResult.build(201, e.getMessage());
		}
	}

	/**
	 * 登陆模块
	 * userId记录 ticket，ticket记录租期剩余时间
	 * 一旦登陆即革新userId的ticket。就会顶下另一个上线的人
	 * 
	 */

	@Autowired
	private RedisService redis;
	@Autowired
	private ShardedJedisPool pool;

	@RequestMapping("login")
	@ResponseBody
	public String doLogin(User user) {
		ShardedJedis jedis = pool.getResource();
		user.setUserPassword(MD5Util.md5(user.getUserPassword()));
		// 查询数据库获取user
		User loginUser = userMapper.login(user);
		try {
			if (loginUser != null) {
				/*
				 * redis中：
				 * Ticket： 记录操作时间有效值
				 * Ticket键=JT_TICKET + 时间 + userId 生成 (ticket)
				 * Ticket值=userId的json串
				 */
				//ticket:54bcab328f1b1840cbc4f6f7b722a701
				String ticket = MD5Util.md5("JT_TICKET" + System.currentTimeMillis() + loginUser.getUserId());
				//userJson:e24cc960-bca9-4425-803f-4b709734d6f8
				String userJson = OUtil.mapper.writeValueAsString(loginUser);
				jedis.set(ticket, userJson);
				
				jedis.expire(ticket, 30*60);
				/*
				 * 每次访问,userId键都会更新值为ticket
				 * 删除并重新添加redis中以userId为键的数据证明来过！
				 */
				if(jedis.get(loginUser.getUserId())!=null){
					jedis.del(jedis.get(loginUser.getUserId()));
				}
				jedis.set(loginUser.getUserId(), ticket);
				
				return ticket;//返回ticket的键
			}
			return "";// 说明验证失败,用户名密码不对;
		} catch (Exception e) {
			e.printStackTrace();
			return "/";
		} finally {
			pool.returnResource(jedis);
		}
	}

	/**
	 * ticket 拦截对每次请求进行校验
	 * 
	 * @param ticket 前台的ticket
	 * @param callback jsonp请求会携带callback
	 * @return
	 */
	@RequestMapping("query/{ticket}")
	@ResponseBody
	public String checkLogin(@PathVariable String ticket, String callback) {
		ShardedJedis jedis = pool.getResource();
		// 判断ticket的剩余时间续约
		Long timeOT = jedis.ttl(ticket);
		if (timeOT < 60 * 5) {
			jedis.expire(ticket, (int) (timeOT + (60 * 10)));
		}
		
		// ticket值
		String userJson = jedis.get(ticket);
		String jsonData = "";
		/*
		 * ticket超时：找不带ticket值返回"";
		 */
		try {
			jsonData = OUtil.mapper.writeValueAsString(SysResult.oK(userJson));
		} catch (Exception e) {
			return jsonData; 
		}
		
		if (callback == null) {//json请求
			if (userJson == null) {//ticket值不存在则返回空，存在则返回ticket值
				return userJson;
			}
			return userJson;
		} else {//jsonp请求：手动修改——ticket值封装后的页面jsonp响应格式——的字符串格式
			String result = callback + "(" + jsonData + ")";
			return result;
		}
	}
}