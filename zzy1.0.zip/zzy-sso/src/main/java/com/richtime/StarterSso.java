package com.richtime;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.richtime.zzy.mapper")
public class StarterSso {
	public static void main(String[] args) {
		SpringApplication.run(StarterSso.class, args);
	}
}
