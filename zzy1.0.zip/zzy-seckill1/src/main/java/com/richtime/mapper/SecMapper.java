package com.richtime.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.richtime.common.pojo.Item;

public interface SecMapper {

	List<Item> queryList();

	void updateQuota(@Param("itemId")String itemId, @Param("date")Date time);

}
