package com.richtime.consumer;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.richtime.common.pojo.Item;
import com.richtime.mapper.SecMapper;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

/**
 * 异步监听rabbitmq有没有消息,有就传递给编写消费方法
 * 1 获取消息解析userId,seckillId;
 * 2 连接redis 调用rpop,获取尾部数据,如果返回值为空,说明
 * 已经商品秒杀完了(number=0);如果不为空,说明可以入库;
 * 入库:item表格的项目份额-1,判断是否>0并且当前时间<endTime(sql参数,date,seckillId)
 * 成功表单才能记录成功数据(第二个持久层代码 pojo-mapper-mapper.xml)
 * 3 一旦出现异常逻辑;判断秒杀失败;
 * userId,seckillId
 * @author Administrator
 *
 */
@Component
public class SecConsumer {
	@Autowired
	private SecMapper secMapper;
	@Autowired
	private ShardedJedisPool pool;
//	@Autowired
//	private SucMapper sucMapper;
	
	@RabbitListener(queues="richtimeQ")
	public void seckill(String msg) {
		ShardedJedis sJedis = pool.getResource();
		//解析数据
		String userId = msg.split("/")[0];
		String itemId = msg.split("/")[1];
		String key = msg.split("/")[2];
		Date time = new Date();
		try {
			//通过redis判断秒杀权限
			String result = sJedis.rpop("seclist");
			if(!StringUtils.isNotEmpty(result)) {
				System.out.println("当前用户" + userId + "秒杀失败");
				sJedis.set("result", "秒杀失败");  //result加入redis中用来存放秒杀结果
				sJedis.lpush("seclist", "1");  //秒杀失败，redis回滚
				sJedis.del(key);  //失败，删除redis中新插入的key值
				return;
			}
			seckillDatabase(userId, itemId, time);
		} catch (Exception e) {
			System.out.println(userId + "秒杀失败");
			sJedis.set("result", "秒杀失败");  //result加入redis中用来存放秒杀结果
			sJedis.lpush("seclist", "1");  //秒杀失败，redis回滚
			sJedis.del(key);
			e.printStackTrace();
		} finally {
			pool.returnResource(sJedis);
		}
		//调用数据库执行更新、新增、异常事务回退，回退redis的list，不会造成少卖的问题
	}

	@Transactional
	private void seckillDatabase(String userId, String itemId, Date time) {
		secMapper.updateQuota(itemId, time);  //秒杀库存-1的数据
		//库操作,每个用户只能秒杀一次，一次只能秒杀固定的额度
//		Item item = new Item();
//		item.setItemTotal();
	}

}
