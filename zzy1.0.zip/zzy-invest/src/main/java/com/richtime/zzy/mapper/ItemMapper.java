package com.richtime.zzy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.richtime.common.pojo.Item;

/**
 * 查询项目
 * 
 * @author Cesarchoy
 *
 */
public interface ItemMapper {

	/**
	 * 
	 * @return 总项目数
	 */
	int queryCount();

	/**
	 * 获取页面分页数据
	 * @param start 起始页
	 * @param rows 每页显示数量
	 * @return 全部项目信息的列表
	 */
	List<Item> queryByPage(@Param(value = "start") Integer start, @Param(value = "rows") Integer rows);

	/**
	 * 通过项目id获取项目
	 * @param itemId 项目id
	 * @return 项目
	 */
	Item queryById(String itemId);

	/**
	 * 增加当前已筹备金额
	 * @param itemId 项目id
	 * @param qutoa 投标/秒杀额度
	 * @return 1为成功 0为失败
	 */
	Integer addCurrent(@Param(value = "itemId")String itemId, @Param(value = "qutoa")Float qutoa);

	/**
	 * 查询项目总金额
	 * @param itemId 项目id
	 * @return 项目总金额
	 */
	Float queryTotal(String itemId);

	/**
	 * 查询项目当前筹备金额
	 * @param itemId 项目id
	 * @return 当前筹备金额
	 */
	Float queryCurrent(String itemId);

	/**
	 * 查询项目投标/秒杀金额
	 * @param itemId 项目id
	 * @return 项目投标/秒杀金额
	 */
	Float queryQuota(String itemId);

	/**
	 * 设置项目状态
	 * @param itemId 项目id
	 * @param status 项目状态
	 * @return 1为成功
	 */
	Integer setStatus(@Param(value = "itemId") String itemId, @Param(value = "status") Integer status);

	/**
	 * 查询项目状态
	 * @param itemId 项目id
	 * @return 0为可投资状态
	 */
	Integer queryStatus(String itemId);

	List<Item> getHomePageItems();

}
