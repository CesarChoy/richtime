package com.richtime.zzy.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.richtime.common.pojo.Invest;
import com.richtime.common.pojo.Item;
import com.richtime.common.pojo.User;
import com.richtime.common.util.OUtil;
import com.richtime.common.util.UUIDUtil;
import com.richtime.common.vo.MyResult;
import com.richtime.common.vo.Page;
import com.richtime.common.vo.SysResult;
import com.richtime.zzy.mapper.InvestMapper;
import com.richtime.zzy.mapper.ItemMapper;
import com.richtime.zzy.mapper.UserMapper;

@RestController
public class ItemController {

	@Autowired
	ItemMapper itemMapper;
	
	@Autowired
	UserMapper userMapper;

	@Autowired
	InvestMapper investMapper;
	
	@RequestMapping("/test")
	public String test() {
		return "hello";
	}

	// 查询获取项目总页数、全部项目信息列表
	@RequestMapping("/invest/items")
	public Page queryItemsByPage(Integer currentPage, Integer rows) {
		Page page = new Page();
		// 当前页
		page.setCurrentPage(currentPage);
		// 总页数
		int numbers = itemMapper.queryCount();
		int totalPage = (numbers % rows == 0) ? (numbers / rows) : (numbers / rows + 1);
		page.setTotalPage(totalPage);
		// 全部项目信息列表
		int start = (currentPage - 1) * rows;
		List<Item> items = itemMapper.queryByPage(start, rows);
		page.setItems(items);
		return page;
	}

	// 通过itemId查询item
	@RequestMapping("/invest/particulars/{itemId}")
	public Item queryItemById(@PathVariable String itemId) {
		Item item = itemMapper.queryById(itemId);
		return item;
	}

	// 用户投资
	@RequestMapping("/invest/bid/{itemId}")
	public SysResult bidItemById(HttpServletRequest request, @PathVariable String itemId) {

		/*
		 * 查看投资项目状态是否可操作
		 */
		int itemStatus = itemMapper.queryStatus(itemId);
		if(itemStatus!=0){
			return SysResult.build(201, "该项目投资金额已足够");
		}
		
		/*
		 * 用户表操作： 判断用户金额是否足够 用户金额减少
		 */
		//String userId = (String) request.getAttribute("userId");
		//测试：用户id为1
		String userId = "1";
		User user = userMapper.queryUserById(userId);
		Float cash = user.getUserCash();//用户余额
		Float qutoa = itemMapper.queryQuota(itemId);//项目投标金额
		if (cash < qutoa) {
			return SysResult.build(201, "您的金额不够");
		}
		Integer reduceCash = userMapper.reduceCash(userId,qutoa);//扣费
		/*
		 * 项目表操作： 项目金额增加，判断是否已满
		 */
		Integer addCurrent= itemMapper.addCurrent(itemId,qutoa);//增加金额
		Float itemTotal = itemMapper.queryTotal(itemId);//项目总金额
		Float itemCurrent = itemMapper.queryCurrent(itemId);//查询当前筹备状态
		if(itemTotal-itemCurrent==0){
			int success = itemMapper.setStatus(itemId,1);
		}
		
		/*
		 * 用户投资记录
		 */
		Invest invest = new Invest();
		invest.setInvestId(UUIDUtil.getUUID());
		invest.setItemId(itemId);
		invest.setUserId(userId);
		Integer record= investMapper.record(invest);//记录
		return SysResult.build(200, "恭喜你购买成功");
	}
	
	
	
	//首页查询逻辑
	@RequestMapping("invest_ajax/queryInvest")
	@ResponseBody
	public String getHomePageItems(String callback) throws JsonProcessingException{
		MyResult myresult = new MyResult();
		List<Item> list= itemMapper.getHomePageItems();
		myresult.setItems(list);
		String result = OUtil.mapper.writeValueAsString(myresult);
		return callback+"("+result+")";
	}
	

}
