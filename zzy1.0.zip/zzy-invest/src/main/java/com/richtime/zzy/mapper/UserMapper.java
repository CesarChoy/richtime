package com.richtime.zzy.mapper;


import org.apache.ibatis.annotations.Param;

import com.richtime.common.pojo.User;

/**
 * 用户表操作
 * @author Cesarchoy
 *
 */
public interface UserMapper {

	/**
	 * 用户投标扣费
	 * @param userId 用户id
	 * @return 1为成功 0为失败
	 */
	Integer reduceCash(@Param(value = "userId")String userId, @Param(value = "qutoa")Float qutoa);
	
	/**
	 * 通过userId查询Users
	 * @param userId
	 * @return User
	 */
	User queryUserById(String userId);

}
