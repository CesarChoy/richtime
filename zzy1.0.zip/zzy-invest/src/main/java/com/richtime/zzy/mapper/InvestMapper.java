package com.richtime.zzy.mapper;

import org.springframework.data.repository.query.Param;

import com.richtime.common.pojo.Invest;

public interface InvestMapper {

	/**
	 * 增加投资记录
	 * @param invest 一条投资记录
	 * @return 1为成功 0为失败
	 */
	Integer record(Invest invest);
	
	
}
