package com.richtime.loan.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.richtime.common.pojo.Loan;
import com.richtime.common.util.UUIDUtil;
import com.richtime.common.vo.SysResult;
import com.richtime.loan.mapper.LoanMapper;

@Controller
public class LoanController {

	@Autowired
	LoanMapper loanMapper;

	@RequestMapping("/applyloan")
	@ResponseBody
	public SysResult loan(HttpServletRequest request, Loan loan) {
		/**
		 * 准备数据
		 */
		loan.setLoansId(UUIDUtil.getUUID());
		loan.setLoansDate(new Date());
		loan.setLoansStatus("0");// 贷款状态为字符串
		// String userId = (String) request.getAttribute("userId");
		String userId = "1";// 测试id=1
		loan.setUserId(userId);
		float loansPeriods = loan.getLoansPeriods();
		if (loansPeriods - 3 == 0) {
			loan.setLoansRate(8);
		} else if (loansPeriods - 6 == 0) {
			loan.setLoansRate(10);
		} else if (loansPeriods - 12 == 0) {
			loan.setLoansRate(12);
		} else {
			loan.setLoansRate(15);
		}
		Float loansReturnMoney = loan.getLoansMoney() * (1 + (loan.getLoansRate() / 100 * loansPeriods / 12))
				/ loan.getLoansPeriods();
		loan.setLoansReturnMoney(loansReturnMoney);
		/**
		 * 贷款：贷款成功，用户余额增加
		 */
		Integer loanResult = loanMapper.insertLoan(loan);
		if (loanResult == 1) {
			Integer addCash = loanMapper.userAddCash(userId, loan.getLoansMoney());
			return SysResult.build(200, 
					"恭喜您贷款成功" + loan.getLoansMoney() + "元,"
					+"您的还款周期为" + loan.getLoansPeriods() + "个月," 
					+ "每期需要归还" + loansReturnMoney + "元");
		} else {
			return SysResult.build(201, "贷款失败");
		}
	}
}
