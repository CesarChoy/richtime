package com.richtime.loan.mapper;

import org.apache.ibatis.annotations.Param;

import com.richtime.common.pojo.Loan;

public interface LoanMapper {
	
	/**
	 * 贷款所有相关信息
	 * @param loan 贷款表
	 * @return 1 成功 0 失败
	 */
	Integer insertLoan(Loan loan);

	/**
	 * 用户余额添加
	 * @param userId 用户id
	 * @param loansMoney 贷款金额
	 * @return 1 成功 0 失败
	 */
	Integer userAddCash(@Param(value="userId")String userId,@Param(value="loansMoney") Float loansMoney);

}
