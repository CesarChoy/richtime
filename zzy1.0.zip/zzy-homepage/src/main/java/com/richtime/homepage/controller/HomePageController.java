package com.richtime.homepage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.richtime.common.pojo.Invest;
import com.richtime.common.util.OUtil;
import com.richtime.common.vo.HomePageTotalInfo;
import com.richtime.homepage.mapper.HomePageMapper;

@Controller
public class HomePageController {
	
	@Autowired
	private HomePageMapper mapper;
	
	@RequestMapping("invest_ajax/totalInfo")
	@ResponseBody
	public String queryTotal(Model model,String callback) throws JsonProcessingException{
		HomePageTotalInfo info= new HomePageTotalInfo();
		Float totalInvestsMoney = mapper.findInvestsMoney();
		Float totalLoansMoney = mapper.findLoansMoney();
		int itemNumber = mapper.findItemNumber();
		int userNumber = mapper.findUserNumber();
		
		info.setTotalInvestMoney(totalInvestsMoney);
		info.setTotalLoanMoney(totalLoansMoney);
		info.setItemNumber(itemNumber);
		info.setUserNumber(userNumber);
		String json = OUtil.mapper.writeValueAsString(info);
		json = callback +"("+json+")";
		return json;
	}
	
	
	@RequestMapping("queryall")
	@ResponseBody
	public Invest queryAll(){
		Invest invest = mapper.findOne();
		
		
		return invest;
	}
}
