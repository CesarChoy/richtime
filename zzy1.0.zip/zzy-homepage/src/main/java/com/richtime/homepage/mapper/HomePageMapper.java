package com.richtime.homepage.mapper;

import com.richtime.common.pojo.Invest;

public interface HomePageMapper {

	Float findInvestsMoney();

	Float findLoansMoney();

	int findItemNumber();

	int findUserNumber();

	Invest findOne();

}
