package com.richtime.web.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import com.richtime.common.config.HttpClientService;
import com.richtime.common.pojo.Item;
import com.richtime.common.pojo.Loan;
import com.richtime.common.pojo.User;
import com.richtime.common.util.OUtil;
import com.richtime.common.vo.HttpResult;
import com.richtime.common.vo.Page;
import com.richtime.common.vo.SysResult;
/**
 * 
 * @author Cearchoy
 *
 */
@Service
public class LoanService {

	@Autowired
	private HttpClientService client;
	
	@ResponseBody
	public SysResult applyloan(Loan loan) throws Exception {
		String url = "http://127.0.0.1:8005/applyloan";
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("loansRate", loan.getLoansRate());
		map.put("loansMoney", loan.getLoansMoney());
		map.put("loansPeriods", loan.getLoansPeriods());
		HttpResult result = client.doPost(url, map);
		String jsonData = result.getBody();
		SysResult sysResult = OUtil.mapper.readValue(jsonData, SysResult.class); 
		return sysResult;
	}
	
	
}
