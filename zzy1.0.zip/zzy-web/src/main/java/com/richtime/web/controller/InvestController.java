package com.richtime.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.richtime.common.pojo.Item;
import com.richtime.common.vo.Page;
import com.richtime.common.vo.SysResult;
import com.richtime.web.service.ItemService;
/**
 * 
 * @author Cearchoy
 *
 */
@Controller
public class InvestController {

	@Autowired
	private ItemService itemService;
	
	/**
	 * 投资项目分页
	 * @param currentPage 当前页数
	 * @param rows 每页显示数量
	 * @param model 携带参数
	 * @return 页面跳转至WEB-INF/invest.jsp
	 */
	@RequestMapping("/invest/items")
	public String investItems(Integer currentPage,Integer rows,Model model){
		Page page=itemService.queryByPage(currentPage,rows);
		model.addAttribute("page", page);
		return "invest";
	}
	
	/**
	 * 项目详情
	 * @param itemId 项目id
	 * @param model 携带参数
	 * @return 跳转至WEB-INF/particulars.jsp
	 */
	@RequestMapping("/invest/particulars/{itemId}")
	public String investItem(@PathVariable String itemId,Model model){
		Item item = itemService.queryItem(itemId);
		model.addAttribute("item",item);
		return "particulars";
	}
	
	/**
	 * 投资项目
	 * @param itemId 项目id
	 * @param model 携带参数
	 * @return 跳转至WEB-INF/particulars.jsp
	 */
	@RequestMapping("/invest/bid/{itemId}")
	public String invest(@PathVariable String itemId,Model model){
		SysResult sysResult = itemService.invest(itemId);
		Item item = itemService.queryItem(itemId);
		model.addAttribute("item",item);
		return "particulars";
	}
}
