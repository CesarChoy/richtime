package com.richtime.web.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.richtime.common.config.HttpClientService;
import com.richtime.common.util.OUtil;
import com.richtime.common.vo.MyResult;


@Service
public class MyinfoService {

	@Autowired
	private HttpClientService client ;
	
	// 获取后台返回的结果
	public MyResult queryList(String userId) {
		// 向后台发送带有userId的请求，并获取结果
		String url = "http://localhost:8004/user/myself/"+userId;
		try {
			String jsonData = client.doGet(url);
			// 将给定的json字符串反序列化为json
			MyResult result =  OUtil.mapper.readValue(jsonData, MyResult.class);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}

}
