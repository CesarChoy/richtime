package com.richtime.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.richtime.common.config.HttpClientService;
import com.richtime.common.pojo.Item;
import com.richtime.common.util.OUtil;
import com.richtime.common.vo.SysResult;

/**
 * 通过HttpClientService连接zzy-seckill项目
 * @author Administrator
 *
 */
@Service
public class SecService {
	@Autowired
	private HttpClientService client;
	private ObjectMapper mp = OUtil.mapper;
	
	public List<Item> queryList() {
		String url = "http://localhost:8001/page/activity";  //zzy-seckill项目访问地址
		try {
			String jsonData = client.doGet(url);
			//解析jsonNode对象
			JsonNode data = mp.readTree(jsonData);
			//准备一个返回的list数据
			List<Item> secList = null;
			if(data.isArray() && data.size()>0) {
				//将zzy-seckill项目中的SecController类的queryList()返回值赋给secList
				secList = mp.readValue(data.traverse(), mp.getTypeFactory().constructCollectionType(List.class, Item.class));
			}
			return secList;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public SysResult getSecInfo(String userId) {
		String url = "http://localhost:8001/page/info/"+userId;
		try {
			String jsonData = client.doGet(url);
			SysResult data = mp.readValue(jsonData, SysResult.class);
			
			return data;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
