package com.richtime.web.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.richtime.common.config.RedisService;
import com.richtime.common.pojo.User;
import com.richtime.common.util.CookieUtils;
import com.richtime.common.vo.SysResult;
import com.richtime.web.service.SsoService;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

@Controller
public class SsoController {
	
	@Autowired
	private SsoService ssoService;
	
	@RequestMapping("/user_ajax/checkUserPhone")
	@ResponseBody
	public SysResult checkUsername(@RequestParam(value="userPhone")String userPhone){
		SysResult result=ssoService.checkUserPhone(userPhone);
		return result;
	}
	
	//表单提交数据新增
	@RequestMapping("/user_ajax/regist")
	@ResponseBody
	public SysResult saveUser(User user){
			try {
				SysResult sysResult = ssoService.saveUser(user);
				return sysResult;
			} catch (Exception e) {
				e.printStackTrace();
				return SysResult.build(201, e.getMessage());
			}
	}
	
	//登录
	@RequestMapping("user_ajax/login")
	@ResponseBody
	public SysResult doLogin(User user,HttpServletRequest request,
			HttpServletResponse response){
 		String ticket=ssoService.doLogin(user);
		if(StringUtils.isNotEmpty(ticket)){
			CookieUtils.setCookie(request, response, 
					"JT_TICKET", ticket);
			return SysResult.build(200, "登陆成功！");
		}else{
			return SysResult.build(201, "登录失败！");
		}
	}
	
	@Autowired
	private RedisService redisService;
	
	@Autowired
	private ShardedJedisPool pool;
	//注销
	@RequestMapping("user_ajax/logout")
	public String logout(HttpServletRequest request,HttpServletResponse response){
		ShardedJedis jedis = pool.getResource();
		
		Cookie[] cookies = request.getCookies();
		String token = "JT_TICKET";
		for (Cookie cookie : cookies) {
			if(cookie.getName()==token) {
				String value = cookie.getValue();
				jedis.del(value);
			}
		} 
		CookieUtils.deleteCookie(request, response, "JT_TICKET");
		return "redirect:/";
	}
	
}
