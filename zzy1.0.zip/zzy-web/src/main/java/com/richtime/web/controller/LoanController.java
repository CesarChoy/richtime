package com.richtime.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.richtime.common.pojo.Loan;
import com.richtime.common.vo.SysResult;
import com.richtime.web.service.LoanService;
/**
 * 
 * @author Cearchoy
 *
 */
@Controller
public class LoanController {

	@Autowired
	private LoanService loanService;

	@RequestMapping("/loan/applyloan")
	@ResponseBody
	public SysResult apply(Loan loan){
		try {
			SysResult sysResult = loanService.applyloan(loan);
			return sysResult;
		} catch (Exception e) {
			e.printStackTrace();
			return SysResult.build(201, e.getMessage());
		}
	}
	
}
