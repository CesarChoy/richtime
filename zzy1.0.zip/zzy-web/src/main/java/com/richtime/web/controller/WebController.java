package com.richtime.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.richtime.common.pojo.Item;
import com.richtime.common.vo.HomePageTotalInfo;
import com.richtime.common.vo.MyResult;
import com.richtime.web.service.WebService;

@Controller
public class WebController {
	
	@RequestMapping("/")
	public String index(){
		return "index";
	}
	@RequestMapping("page/{page}")
	public String go(@PathVariable String page){
		return page;  
	}
	
	
}
