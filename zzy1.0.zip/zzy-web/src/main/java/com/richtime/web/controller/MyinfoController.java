package com.richtime.web.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.richtime.common.vo.MyResult;
import com.richtime.web.service.MyinfoService;



@Controller
public class MyinfoController {
	
	@Autowired
	private MyinfoService userService;
	@RequestMapping("/user/myself")
	public String queryList(Model model,HttpServletRequest request){
		String userId = (String) request.getAttribute("userId");
		try {
			MyResult result = userService.queryList(userId);
			model.addAttribute("result",result);
		} catch (Exception e) {
			e.printStackTrace();
			return "/";
		}	
		return "myinfo";
	}
		

}
