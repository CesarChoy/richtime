package com.richtime.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.richtime.common.config.HttpClientService;
import com.richtime.common.config.RedisService;
import com.richtime.common.pojo.Item;
import com.richtime.common.util.OUtil;
import com.richtime.common.vo.HomePageTotalInfo;
import com.richtime.common.vo.Page;

@Service
public class WebService {
	
	
	
	

	
}
