package com.richtime.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.richtime.common.config.HttpClientService;
import com.richtime.common.pojo.Item;
import com.richtime.common.util.OUtil;
import com.richtime.common.vo.Page;
import com.richtime.common.vo.SysResult;
/**
 * 
 * @author Cearchoy
 *
 */
@Service
public class ItemService {

	@Autowired
	private HttpClientService client;

	public Page queryByPage(Integer currentPage, Integer rows) {
		try {
			String url = "http://127.0.0.1:8002"
					+ "/invest/items/?currentPage=" + currentPage + "&rows=" + rows;
			String jsonData = client.doGet(url);
			Page page = OUtil.mapper.readValue(jsonData, Page.class);
			return page;
		} catch (Exception e) {
			System.out.println("连接后台出现异常:" + e.getMessage());
			return null;
		}
	}

	public Item queryItem(String itemId) {
		try {
			String url = "http://127.0.0.1:8002"
					+ "/invest/particulars/"+itemId;
			String jsonData = client.doGet(url);
			Item item = OUtil.mapper.readValue(jsonData, Item.class);
			return item;
		} catch (Exception e) {
			System.out.println("连接后台出现异常:" + e.getMessage());
			return null;
		}
	}

	public SysResult invest(String itemId) {
		try {
			String url = "http://127.0.0.1:8002"
					+ "/invest/bid/"+itemId;
			String jsonData = client.doGet(url);
			SysResult sysResult = OUtil.mapper.readValue(jsonData, SysResult.class);
			return sysResult;
		} catch (Exception e) {
			System.out.println("连接后台出现异常:" + e.getMessage());
			return null;
		}
	}

}
