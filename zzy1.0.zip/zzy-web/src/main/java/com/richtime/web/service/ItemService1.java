package com.richtime.web.service;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import com.richtime.common.config.HttpClientService;
import com.richtime.common.config.RedisService;
import com.richtime.common.pojo.Item;
import com.richtime.common.util.OUtil;
import com.richtime.common.util.UUIDUtil;
import com.richtime.common.vo.EasyUIResult;
import com.richtime.common.vo.HttpResult;
import com.richtime.common.vo.Page;
@Service
public class ItemService1 {
	
	@Autowired
	private HttpClientService client;
	public Page queryByPage(Integer currentPage, Integer rows) {
		try {
			String url="http://localhost:8007/item/pageQuery?page="+currentPage+"&rows="+rows;
			String jsonData=client.doGet(url);
			//解析page对象的json为page对象
			Page page=OUtil.mapper.readValue(jsonData,Page.class);
			return page;
		} catch (Exception e) {
			
			System.out.println("连接后台出现了异常："+e.getMessage());
			return null;
		}
	}
	
	@Autowired(required=false)
	private RedisService redis;
	
	public Item queryById(String itemId) {
		/*生成key值:key与业务有关于唯一值有关
		 *判断缓存存在
		 *	存在则直接使用,
		 *  不存在则访问后台*/
		//查询单个商品的缓存,配合httpClient访问后台
			try {
				String key="item_"+itemId;
				if(redis.exists(key)){
					//有就直接用
				String jsonData=redis.get(key);
				Item item=OUtil.mapper.readValue(jsonData, Item.class);
				return item;
				}else{
					//不存在则访问后台manage系统获取返回json
					String url="localhost:8007/item/queryById/"+itemId;
					//doGet(url)没有其他参数
					String jsonData=client.doGet(url);
					//set缓存
					redis.set(key, jsonData);
					//解析数据
					Item item=OUtil.mapper.readValue(jsonData, Item.class);
					return item;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
		}
	}

	public EasyUIResult manangeQueryList(Integer page, Integer rows) {
		
		try {
			String url="http://localhost:8007/item/pageQuery?page="+page+"&rows="+rows;
			String jsonData;
			jsonData = client.doGet(url);
			EasyUIResult result=OUtil.mapper.readValue(jsonData, EasyUIResult.class);
			return result;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	
	}

	public int saveProduct(Item item) {
		String url="http://localhost:8007/item/save";
		//map保存多个key-value,每一个key-value都是product属性名和属性值
		Map<String,Object> map=new HashMap<String,Object>();
		//封装所有参数
		map.put("itemId", UUIDUtil.getUUID());
		map.put("itemName", item.getItemName());
		map.put("itemTime", item.getItemTime());
		map.put("itemRate", item.getItemRate());
		map.put("itemTotal", item.getItemTotal());
		map.put("itemStatus", item.getItemStatus());
		map.put("itemCompany", item.getItemCompany());
		map.put("itemLocation", item.getItemLocation());
		map.put("itemDescription", item.getItemDescription());
		map.put("itemStartTime", item.getItemStartTime());
		map.put("itemQuota", item.getItemQuota());
		map.put("itemSeckillStart", item.getItemSeckillStart());
		map.put("itemSeckillStop", item.getItemSeckillStop());
		try{
			//doget区别返回结果,封装的是HttpResult
			//获取响应体,getBody()方法
			HttpResult result =client.doPost(url, map);
			int success=Integer.parseInt(result.getBody());//"1","0"
			return success;
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
