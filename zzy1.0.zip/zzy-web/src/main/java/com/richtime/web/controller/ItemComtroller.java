package com.richtime.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import com.richtime.common.pojo.Item;
import com.richtime.common.vo.EasyUIResult;
import com.richtime.common.vo.Page;
import com.richtime.common.vo.SysResult;
import com.richtime.web.service.ItemService1;

@Controller
public class ItemComtroller {
	@Autowired
	private ItemService1 itemService;
	//全部商品的分页查询
	@RequestMapping("/item/page")
	public String queryByPage(Integer currentPage,Integer rows,Model model){
		Page page=itemService.queryByPage(currentPage,rows);
		model.addAttribute("page", page);
		return "item_list";
	}
	
	//单个商品根据id查询数据，返回商品对象
	@RequestMapping("item/findItemById/{itemId}")
	public String queryById(@PathVariable String itemId,Model model){
		Item item=itemService.queryById(itemId);
		model.addAttribute("item",item);
		return "item_info";
	}
	
	
	//后台分页查询
	@RequestMapping("/page/item-list")
	
	public String manageQueryList(@RequestParam(defaultValue="1")Integer page,@RequestParam(defaultValue="20")Integer rows,Model model){
		System.out.println("可以查询了");
		EasyUIResult result=itemService.manangeQueryList(page,rows);
		model.addAttribute("result", result);
		return "item-list";
	}
	
	
	@RequestMapping("item/save")
	public String saveProduct(Item item,Model model){
		System.out.println("可以存了");
		//判断存储成功失败,成功返回200的sysresult,失败返回201
		//利用执行结果 int success=1/0,异常判断成功失败
		try{
			int success=itemService.saveProduct(item);
			//success=1表示数据库新增成功
			if(success==1){
				model.addAttribute("addInfo", "添加成功");
				return "manage";
				//ok的静态方法,返回一个status=200,msg=ok的对象
			}
			
			return "manage";
			//类似于ok的静态方法,build返回一个传递参数封装的SysResult对象
		}catch(Exception e){
			e.printStackTrace();
			model.addAttribute("addInfo", "添加失败");
			return "manage";
		}
	}
	
	
	
	
	
	
	
	
}
