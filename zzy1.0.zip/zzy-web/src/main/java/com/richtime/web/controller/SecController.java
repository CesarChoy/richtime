package com.richtime.web.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.richtime.common.config.RedisService;
import com.richtime.common.pojo.Item;
import com.richtime.common.vo.SysResult;
import com.richtime.web.service.SecService;

/**
 * 访问连接地址，进入秒杀项目的list，将查询的list直接返回给页面for循环展示
 * 请求地址：http://www.richtime.com/page/activity
 * 请求方式：get
 * 请求参数：空，判断登录，设置userId传给controller，拦截器逻辑
 * 返回数据：页面解析地址"activity",model携带数据secList对象
 * @author Administrator
 *
 */
@Controller
public class SecController {
	@Autowired
	private SecService secService;
	
	/**
	 * 实现秒杀项目的list查询
	 * @param model
	 * @return
	 */
	@RequestMapping("seckill/activity")
	public String queryList(Model model) {
		//注入的service调用查询方法
		List<Item> secList = secService.queryList();
		model.addAttribute("list", secList);
		return "activity";
	}
	
	//seckill/time/now返回当前系统时间
	@RequestMapping("seckill/time/now")
	@ResponseBody
	public Date nowTime() {
		return new Date();
	}
	
	//成功的入库逻辑
	//用户发起秒杀请求，秒杀项目，携带项目id，拦截器获取userId
	//将其封装成消息扔到队列，有后端的消费者并发处理入库逻辑
	@Autowired
	private RabbitTemplate temp;
	@Autowired
	private RedisService redis;
	
	@RequestMapping("seckill/{itemId}")
	@ResponseBody
	public SysResult startSeckill(HttpServletRequest request,@PathVariable String itemId) {
		//拿到userId
		String userId = (String) request.getAttribute("userId");
	//	String userId = "335818420";
		String key = "seckill_" + userId + "_" + itemId;
		String msg = userId + "/" + itemId + "/" + key;
		//redis引入,利用userId作为key值,判断是否秒杀过一次
		
		
		if(redis.exists(key)) {  //存在，说明已经秒杀过一次
			System.out.println("您已经投过该项目");
			request.setAttribute("result", "您已经投过该项目");
			System.out.println("request:" + request.getAttribute("result"));
			return SysResult.build(201, "已投过该项目");
		}
		//每次一个userId在redis缓存中，只能存在一个值，如果存在userId则说明该用户已经秒杀过，可以使用前缀
		System.out.println("开始秒杀");
		redis.set(key, "开始秒杀");
		temp.convertAndSend("richtimeDEX", "seckill.start", msg);
		
		do {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} while (!redis.exists("result" + userId));
			
		String secMsg = redis.get("result" + userId);
		if("200".equals(secMsg)){
			return SysResult.build(200, "秒杀成功","1");
		}
		if("201".equals(secMsg)){
			return SysResult.build(201, "秒杀失败","1");
		}
		
		return SysResult.build(201, "秒杀失败","1");
		
		
		/*if(redis.exists("result" + userId)) { 
			//存在，说明redis的result中存了秒杀失败的信息
//			model.addAttribute("result", "秒杀失败，请稍后重试");
			return SysResult.build(202, "秒杀失败","1");
		}else{
			return SysResult.build(201, "秒杀成功","1");
		}*/
		
	}
	
	
	@RequestMapping("seckill/getSecStatus")
	@ResponseBody
	public SysResult getSecInfo(HttpServletRequest request){
		String userId = (String) request.getAttribute("userId");
		SysResult result  = secService.getSecInfo(userId);
		 
		return result;
	}

}
