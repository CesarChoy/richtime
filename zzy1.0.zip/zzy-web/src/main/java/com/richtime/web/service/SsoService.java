package com.richtime.web.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.richtime.common.config.HttpClientService;
import com.richtime.common.pojo.User;
import com.richtime.common.util.OUtil;
import com.richtime.common.vo.HttpResult;
import com.richtime.common.vo.SysResult;

@Service
public class SsoService {
	
	@Autowired
	private HttpClientService client;
	
	public SysResult checkUserPhone(String userPhone) {
		String url = "http://127.0.0.1:8006/user/check/" + userPhone;
		try {
			String jsonData = client.doGet(url);
			SysResult sysResult = OUtil.mapper.readValue(jsonData, SysResult.class); 
			return sysResult;
		} catch (Exception e) {
			return SysResult.build(201, e.getMessage());
		}
	}

	public SysResult saveUser(User user) throws Exception {
		String url = "http://127.0.0.1:8006/user/register";
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("userPhone", user.getUserPhone());
		map.put("userPassword", user.getUserPassword());
		map.put("userNickname", user.getUserNickname());
		HttpResult result = client.doPost(url, map);
		String jsonData = result.getBody();
		SysResult sysResult = OUtil.mapper.readValue(jsonData, SysResult.class); 
		return sysResult;
	}

	public String doLogin(User user) {
		String url = "http://127.0.0.1:8006/login";
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("userPhone", user.getUserPhone());
		map.put("userPassword", user.getUserPassword());
		try {
			String ticket = client.doPost(url, map).getBody();
			return ticket;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

}
