package com.richtime.adaptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.richtime.interceptors.SeckillInterceptor;




@Component
public class WebInterceptors extends WebMvcConfigurerAdapter{
	@Autowired
	private SeckillInterceptor se;
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(se)
		.addPathPatterns("/seckill/**").addPathPatterns("/user/myself");
		/*registry.addInterceptor(oi)
		.addPathPatterns("/order/**");
		registry.addInterceptor(si)
		.addPathPatterns("/seckill/**");*/
		super.addInterceptors(registry);
	}
	

}
