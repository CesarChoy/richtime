package com.richtime.config;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix="cluster")
public class ESConfig {
	private String nodes;
	private String name;
	
	
	@Bean
	public TransportClient initialize(){
		
		try {
			//准备一个setting配置对象，集群名字叫elasticsearch
			Settings setting = Settings.builder().
					put("cluster.name",name).build();
			//建立连接对象
			TransportClient client = new PreBuiltTransportClient(setting)	;
			String[] hostAndPort = nodes.split(",");
			for(String node:hostAndPort){
				String host = node.split(":")[0];
				int port = Integer.parseInt(node.split(":")[1]);
				InetSocketTransportAddress ISTA1 = new InetSocketTransportAddress(InetAddress.getByName(host),port);
				client.addTransportAddress(ISTA1);
			}
			return client;
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	public String getNodes() {
		return nodes;
	}
	public void setNodes(String nodes) {
		this.nodes = nodes;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
