package com.richtime.elasticsearch.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.richtime.common.pojo.Item;
import com.richtime.common.util.OUtil;
import com.richtime.common.vo.MyResult;
import com.richtime.common.vo.Page;
import com.richtime.elasticsearch.mapper.ItemMapper;


@Controller

public class SearchController {
	@Autowired
	private TransportClient client;

	@Autowired 
	private ItemMapper itemmapper;
	
	//将item数据库数据存入索引
	 @RequestMapping("creating")
	 @ResponseBody
	 public String createData () throws JsonProcessingException{
		ObjectMapper mapper = new ObjectMapper();
		
		int currentPage = 1;
		int rows = 5;
		Integer start=(currentPage-1)*rows;
		List<Item> pList=itemmapper.queryByPage(start,rows);
		Integer totalitem=itemmapper.queryCount();
		Integer totalPage=totalitem%rows==0?
				totalitem/rows:totalitem/rows+1;
		Page page=new Page();
		page.setCurrentPage(currentPage);
		page.setItems(pList);
		page.setTotalPage(totalPage);
		
		List<Item> qList= (List<Item>) page.getItems();
		//item 对象document对象
		for(Item item:qList){
			String source =  mapper.writeValueAsString(item);
			//index , 类型  id 
			client.prepareIndex("zzydb1", "item", item.getItemId())
			.setSource(source).get();
		}
		return "";
		}
		

	@RequestMapping("search")
	//默认索引中页面最少有是1. 避免异常
	@ResponseBody
	public String queryItem(
	@RequestParam(defaultValue="1")Integer page,String q,String callback) throws Exception{
		//创建查询条件， 查询索引中，ItemName域zhi	
		
		ObjectMapper mapper=new ObjectMapper();
		QueryBuilder query=QueryBuilders.matchQuery("itemName", q);
		//实际查询击中	
		int start=(page-1)*5;
		SearchResponse response=client.prepareSearch("zzydb1").setQuery(query).
		setFrom(start).setSize(5).get();
		SearchHits hits=response.getHits();
		//创建容器
		
		List<Item> qList=new ArrayList<Item>();
		for(SearchHit hit:hits){
			//击中文档转换json,json 做成item对象
			Item item=mapper.readValue(hit.getSourceAsString(),Item.class);
		   qList.add(item);
		   
		}
		 //将击中对象封装到myresult中，转换成jsondata
		//将qlist容器转换成json 封装成json数据
		String jsonData="";
		try{
			 
			MyResult myResult = new MyResult();
			myResult.setItems(qList);
			jsonData=OUtil.mapper.writeValueAsString(myResult);
			String result=callback+"("+jsonData+")";
			return  result;
		}catch(Exception e){
			e.printStackTrace();
			return "查询失败";
		}
		
	}

}
