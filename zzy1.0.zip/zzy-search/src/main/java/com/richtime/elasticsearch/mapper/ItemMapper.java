package com.richtime.elasticsearch.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.richtime.common.pojo.Item;

public interface ItemMapper {

	List<Item> queryByPage(@Param(value = "start") Integer start, @Param(value = "rows") Integer rows);

	Integer queryCount();

}
