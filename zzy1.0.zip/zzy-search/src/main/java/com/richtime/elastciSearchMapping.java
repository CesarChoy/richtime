package com.richtime;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import org.elasticsearch.action.admin.indices.mapping.put.PutMappingRequest;
import org.elasticsearch.client.IndicesAdminClient;
import org.elasticsearch.client.Requests;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.junit.Before;
import org.junit.Test;


public class elastciSearchMapping {
	private TransportClient client;
	private static final String indexName="zzydb1";
	private static final String type="item";
	
	@Before
	public void initzzy() throws Exception{
	Settings setting=Settings.builder().
			put("cluster.name", "ltq-es").build();
	//创建连接对象
	client=new PreBuiltTransportClient(setting);
	//指定ip,端口,按照需要的连接,add节点信息,准备3个节点的对象
	InetSocketTransportAddress ISTA1=
			new InetSocketTransportAddress(
					InetAddress.getByName("10.42.30.40"), 9300);
	/*InetSocketTransportAddress ISTA2=
			new InetSocketTransportAddress(
					InetAddress.getByName("10.42.12.163"), 9300);
	InetSocketTransportAddress ISTA3=
			new InetSocketTransportAddress(
					InetAddress.getByName("10.42.23.246"), 9300);*/
	/*client.addTransportAddress(ISTA3);
	client.addTransportAddress(ISTA2);*/
	client.addTransportAddress(ISTA1);
	}
	
	
	//映射创建，绑定
	@Test
	   public void zzyCreate() throws Exception{
		  IndicesAdminClient admin = client.admin().indices();//分片对象
		  admin.prepareCreate(indexName).get();
		  
		 
		  
		  //封装mapping结构
		  XContentBuilder builder=XContentFactory.jsonBuilder()
				  .startObject()
				  .startObject("properties")
				  .startObject("itemname").field("type","text").field("analyzer","ik_max_word")
				  .endObject()
				  .startObject("itemrate").field("type","keyword")
				  .endObject()
				  .startObject("itemtime").field("type","keyword")
				  .endObject()
				  .startObject("itemcompany").field("type","keyword")
				  .endObject()
				  .startObject("itemtotal").field("type","keyword")
				  .endObject()
				  .startObject("itemcurrent").field("type","keyword")
				  .endObject()
				  .endObject()
				  .endObject();
		  
		  //绑定
		  PutMappingRequest mapping= Requests.putMappingRequest
				  (indexName).type(type).source(builder);
		  admin.putMapping(mapping).get();
		  
		  
		  
		  
	   } 
}
