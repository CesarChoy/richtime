package com.richtime.controller;

import java.util.ArrayList;
import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.richtime.common.pojo.Item;

import com.richtime.common.vo.SysResult;
import com.richtime.mapper.SecMapper;

@RestController
@RequestMapping("page")
public class SecController {
	
	@Autowired
	private SecMapper secMapper;
	
	//访问数据库，获取秒杀项目的list
	@RequestMapping("activity")
	public List<Item> queryList() {
		return secMapper.queryList();
	}

}
