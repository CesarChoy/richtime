package com.richtime;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@MapperScan("com.richtime.mapper")
public class StarterSec {
	
	public static void main(String[] args) {
		SpringApplication.run(StarterSec.class, args);
	}
	

	// 声明队列
	@Bean
	public Queue queueEM() {
		return new Queue("richtimeQ");
	}

	// 声明交换机
	@Bean
	public DirectExchange ex() {
		return new DirectExchange("richtimeDEX");
	}

	// 声明绑定关系
	@Bean
	public Binding bind() {
		return BindingBuilder.bind(queueEM()).to(ex()).with("product.add");
	}

	@Bean
	public Queue queueSec() {
		return new Queue("richtimeQ");
	}

	@Bean
	public Binding bind02() {
		return BindingBuilder.bind(queueSec()).to(ex()).with("seckill.start");
	}
	
	
}
