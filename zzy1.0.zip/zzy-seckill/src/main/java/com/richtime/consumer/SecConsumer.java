package com.richtime.consumer;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.richtime.common.pojo.Invest;
import com.richtime.common.pojo.Item;
import com.richtime.common.util.UUIDUtil;
import com.richtime.mapper.SecMapper;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

/**
 * 异步监听rabbitmq有没有消息,有就传递给消费方法
 * 1 获取消息解析userId,seckillId;
 * 2 连接redis 调用rpop,获取尾部数据,如果返回值为空,说明
 * 已经商品秒杀完了(number=0);如果不为空,说明可以入库;
 * 入库:item表格的项目份额-1,判断是否>0并且当前时间<endTime(sql参数,date,seckillId)
 * 成功表单才能记录成功数据(第二个持久层代码 pojo-mapper-mapper.xml)
 * 3 一旦出现异常逻辑;判断秒杀失败;
 * userId,seckillId
 * @author Administrator
 *
 */
@Component
public class SecConsumer {
	@Autowired
	private SecMapper secMapper;
	@Autowired
	private ShardedJedisPool pool;
//	@Autowired
//	private SucMapper sucMapper;
	
	@RabbitListener(queues="richtimeQ")
	public void seckill(String msg) {
		ShardedJedis sJedis = pool.getResource();
		
		//解析数据
		String userId = msg.split("/")[0];
		String itemId = msg.split("/")[1];
		String key = msg.split("/")[2];
		Date time = new Date();
		
//		List<Item> secList = secMapper.queryList();
		Item secItem = secMapper.querySecItemById(itemId);
		int num = (int)(secItem.getItemTotal()/secItem.getItemQuota());
		
		sJedis.set("seckill_"+itemId,num+"");
		/*for (Item item : secList) {
			//num 秒杀项目的份额
			int num = (int) (item.getItemTotal() / item.getItemQuota());
			//循环向redis中的seclist存入元素
			for (int i = 0; i < num; i++) {
				sJedis.lpush("seclist_" + itemId, "1");					
			}
		}*/
		//通过redis判断秒杀权限

		sJedis.set("seckill_"+itemId,num-1+"");
		//项目数量为0，用户秒杀失败
		if(sJedis.get("seckill_"+itemId) != null && sJedis.get("seckill_"+itemId).equals("0")) {
			System.out.println("当前用户" + userId + "秒杀失败");
			sJedis.set("result" + userId, "秒杀失败");  //result加入redis中用来存放秒杀结果
			sJedis.set("seckill_"+itemId, num+1+"");//秒杀失败，redis回滚
			sJedis.del(key);
		}
	/*	if(!StringUtils.isNotEmpty(result)) {
			System.out.println("当前用户" + userId + "秒杀失败");
			sJedis.set("result" + userId, "秒杀失败");  //result加入redis中用来存放秒杀结果
			sJedis.lpush("seclist_" + itemId, "1");  //秒杀失败，redis回滚
			sJedis.del(key);  //失败，删除redis中新插入的key值
			return;
		}*/
		
		try {
			
			int type = seckillDatabase(itemId, time, userId);
			if(type == 0) {
				sJedis.set("result" + userId, "201");
				sJedis.set("seckill_"+itemId, num+1+"");
				sJedis.del(key);
			}else{
				sJedis.set("result" + userId, "200");
			}
		} catch (Exception e) {
			System.out.println(userId + "秒杀失败");
			sJedis.set("result" + userId, "201");  //result加入redis中用来存放秒杀结果
			sJedis.set("seckill_"+itemId, num+1+"");//秒杀失败，redis回滚
			sJedis.del(key);
			e.printStackTrace();
		} finally {
			pool.returnResource(sJedis);
		}
		//调用数据库执行更新、新增、异常事务回退，回退redis的list，不会造成少卖的问题
	}

	@Transactional
	private int seckillDatabase(String itemId, Date time,String userId) {
		try {
			
			int type = secMapper.updateQuota(itemId, time);
			/*if(type==1){
				secMapper.insertSecInfo(userId,itemId);
				Item item = secMapper.querySecItemById(itemId);
				Invest invest = new Invest();
				invest.setInvestId(UUIDUtil.getUUID());
				invest.setInvestTotalMoney(item.getItemTotal());
				invest.setItemId(item.getItemId());
				invest.setItemName(item.getItemName());
				invest.setItemRate(item.getItemRate());
				invest.setUserId(userId);
				invest.setInvestDate(new Date());
				secMapper.insertSecIntoInvest(invest);
			}*/
			return  type; //秒杀库存-1的数据
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("秒杀事务失败");
			return 0;
		}
		
		//库操作,每个用户只能秒杀一次，一次只能秒杀固定的额度
		
	}

}
