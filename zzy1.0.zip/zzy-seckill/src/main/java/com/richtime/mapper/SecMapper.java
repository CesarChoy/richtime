package com.richtime.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.richtime.common.pojo.Invest;
import com.richtime.common.pojo.Item;


public interface SecMapper {

	List<Item> queryList();

	int updateQuota(@Param("itemId")String itemId, @Param("date")Date time);

	

	Item querySecItemById(String itemId);

	void insertSecInfo(@Param("userId") String userId,@Param("itemId") String itemId);

	void insertSecIntoInvest(Invest invest);




}
