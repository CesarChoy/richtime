package com.richtime.manage.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.richtime.common.pojo.Item;

public interface ItemMapper {

	int saveItem(Item item);

	List<Item> queryByPage(@Param(value="start")Integer start,@Param(value="rows")Integer rows);

	int queryCount();

	int updateitem(Item item);

	Item queryById(String itemId);

	void deleteById(String itemId);

}
