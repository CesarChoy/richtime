package com.richtime.manage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import com.richtime.common.pojo.Item;
import com.richtime.common.util.UUIDUtil;
import com.richtime.common.vo.EasyUIResult;
import com.richtime.common.vo.Page;
import com.richtime.manage.mapper.ItemMapper;





@Controller
public class ItemController {

	@Autowired
	private ItemMapper itemMapper;
	
	//商品的新增逻辑
		@RequestMapping("item/save")
		@ResponseBody
		public String saveItem(Item item){
			System.out.println("新增逻辑");
			item.setItemId(UUIDUtil.getUUID());
			//mybatis,做了一件事;如果id,是int 自增,新增完毕的时候,
			//product的id也是有数据的,每个数据库的客户端线程,在新增完毕后,mybatis持久层
			//自动调用一个select last_insert_id(),操作是线程安全的
			try{
				itemMapper.saveItem(item);
				System.out.println("存储了");
				return "1";
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("错啦,小老弟");
				return "0";
				
			}
		}
		
		
		@RequestMapping("item/pageQuery")
		@ResponseBody
		public EasyUIResult queryByPage(Integer page,Integer rows){
			//封装page对象，需要当前页，需要plist查询结果，需要totalPage
			Integer start=(page-1)*rows;
			//注入mapper
			//利用其实位置和rows查询分页数据
			List<Item> pList=itemMapper.queryByPage(start,rows);
			EasyUIResult result = new EasyUIResult();
			result.setRows(pList);
			
			
			//totalPage 商品总页数   根据rows不同而改变
			int total=itemMapper.queryCount();
			
			//total,row,计算totalPage;
			
			
			return result;
			
		}
		
		
		//商品的更新
		@RequestMapping("item/update")
		@ResponseBody
		public String updateProduct(Item item){
			itemMapper.updateitem(item);
			return "1";
		}
		
		
		//商品id查询
		@RequestMapping("item/queryById/{itemId}")
		@ResponseBody
		public Item queryById(@PathVariable String itemId){
			Item item = itemMapper.queryById(itemId);
			//缓存??实现前台缓存即可
			return item;
		}
		
		//给商家页面查询的分页
		@RequestMapping("item/queryPages")
		@ResponseBody
		public EasyUIResult queryPages(Integer page,Integer rows){
			int total=itemMapper.queryCount();
			List<Item> pList = itemMapper.
					queryByPage((page-1)*rows, rows);
			//封装EasyUIResult
			EasyUIResult result=new EasyUIResult();
			result.setRows(pList);
			result.setTotal(total);
			return result;
		}
		
		//根据itemId删除项目
		@RequestMapping("item/delete")
		@ResponseBody
		public String deleteById(String itemId,String callback){
			
			itemMapper.deleteById(itemId);
			
			return callback+"()";
		}
		
		
}
